'use strict';
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const { ErroHttp } = require('./validacao');
const { um } = require('./db');

const CUSTO_HASH = 10;
// Hash de mentira, usado para o tempo de resposta ser parecido quando a matrícula não existe.
const HASH_FALSO = bcrypt.hashSync('nao-existe', CUSTO_HASH);

function gerarHash(pin) {
  return bcrypt.hashSync(String(pin), CUSTO_HASH);
}

function conferirPin(pin, hash) {
  return bcrypt.compareSync(String(pin), hash || HASH_FALSO);
}

function criarToken(config, usuario) {
  return jwt.sign({ sub: usuario.id, tv: usuario.token_versao }, config.jwtSecret, {
    algorithm: 'HS256',
    expiresIn: `${config.tokenDias}d`,
  });
}

function usuarioPublico(u) {
  return { id: u.id, matricula: u.matricula, nome: u.nome, funcao: u.funcao, ativo: !!u.ativo };
}

/**
 * Exige login. A cada pedido o usuário é lido do banco, então desativar uma
 * pessoa ou trocar o PIN dela vale na hora, sem esperar o login expirar.
 */
function exigirLogin(db, config) {
  return async (req, _res, next) => {
    try {
      const m = /^Bearer (.+)$/.exec(req.headers.authorization || '');
      if (!m) return next(new ErroHttp(401, 'Faça login para continuar.'));
      let payload;
      try {
        payload = jwt.verify(m[1], config.jwtSecret, { algorithms: ['HS256'] });
      } catch (e) {
        return next(new ErroHttp(401, 'Sua sessão terminou. Entre de novo.'));
      }
      const u = await um(
        db,
        'SELECT id, matricula, nome, funcao, ativo, token_versao FROM usuarios WHERE id = ?',
        [payload.sub ?? null]
      );
      if (!u || !u.ativo || u.token_versao !== payload.tv) {
        return next(new ErroHttp(401, 'Sua sessão terminou. Entre de novo.'));
      }
      req.usuario = u;
      next();
    } catch (e) {
      next(e);
    }
  };
}

function exigirPcm(req, _res, next) {
  if (req.usuario && req.usuario.funcao === 'pcm') return next();
  next(new ErroHttp(403, 'Só o PCM pode fazer isso.'));
}

module.exports = { gerarHash, conferirPin, criarToken, usuarioPublico, exigirLogin, exigirPcm };
