'use strict';
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');

const raiz = path.resolve(__dirname, '..', '..');

/**
 * Lê o arquivo configuracao.env (na pasta do sistema) e põe os valores no ambiente.
 * Variáveis que já existem no ambiente (por exemplo, definidas pela hospedagem) têm prioridade.
 * Formato: uma configuração por linha, CHAVE=valor. Linhas começando com # são comentários.
 */
function lerArquivoEnv() {
  const arquivo = path.join(raiz, 'configuracao.env');
  if (!fs.existsSync(arquivo)) return;
  const texto = fs.readFileSync(arquivo, 'utf8').replace(/^\uFEFF/, '');
  for (const linha of texto.split(/\r?\n/)) {
    const t = linha.trim();
    if (!t || t.startsWith('#')) continue;
    const i = t.indexOf('=');
    if (i < 1) continue;
    const chave = t.slice(0, i).trim();
    let valor = t.slice(i + 1).trim();
    if (valor.length >= 2 && ((valor[0] === '"' && valor.endsWith('"')) || (valor[0] === "'" && valor.endsWith("'")))) {
      valor = valor.slice(1, -1);
    }
    if (!(chave in process.env)) process.env[chave] = valor;
  }
}

/**
 * Lê as configurações do ambiente. Tudo tem um padrão que funciona sem
 * configurar nada, exceto a senha do MySQL; as variáveis servem para ajustar.
 *
 *   DB_HOST      endereço do MySQL (padrão localhost)
 *   DB_PORT      porta do MySQL (padrão 3306)
 *   DB_USER      usuário do MySQL (padrão pcm_app)
 *   DB_PASSWORD  senha do usuário do MySQL
 *   DB_NAME      nome do banco (padrão pcm)
 *   PORT         porta do servidor (padrão 3000)
 *   DATA_DIR     pasta do segredo do login e dos backups (padrão ./data)
 *   JWT_SECRET   segredo dos logins (se faltar, é criado e guardado em DATA_DIR)
 *   TOKEN_DIAS   validade do login em dias (padrão 30)
 *   TRUST_PROXY  defina como 1 quando estiver atrás de proxy (Render, Nginx...)
 */
function carregarConfig(sobrescritas = {}) {
  lerArquivoEnv();
  const dataDir = path.resolve(sobrescritas.dataDir || process.env.DATA_DIR || path.join(raiz, 'data'));
  fs.mkdirSync(dataDir, { recursive: true });

  function segredo() {
    if (sobrescritas.jwtSecret) return sobrescritas.jwtSecret;
    if (process.env.JWT_SECRET) return process.env.JWT_SECRET;
    const arquivo = path.join(dataDir, '.segredo');
    if (fs.existsSync(arquivo)) return fs.readFileSync(arquivo, 'utf8').trim();
    const novo = crypto.randomBytes(48).toString('hex');
    fs.writeFileSync(arquivo, novo, { mode: 0o600 });
    return novo;
  }

  const d = sobrescritas.db || {};
  return {
    raiz,
    dataDir,
    db: {
      host: d.host ?? process.env.DB_HOST ?? 'localhost',
      port: Number(d.port ?? process.env.DB_PORT ?? 3306),
      user: d.user ?? process.env.DB_USER ?? 'pcm_app',
      password: d.password ?? process.env.DB_PASSWORD ?? '',
      database: d.database ?? process.env.DB_NAME ?? 'pcm',
    },
    porta: Number(sobrescritas.porta ?? process.env.PORT ?? 3000),
    jwtSecret: segredo(),
    tokenDias: Number(sobrescritas.tokenDias || process.env.TOKEN_DIAS || 30),
    pastaFrontend: path.join(raiz, 'frontend'),
    trustProxy: sobrescritas.trustProxy ?? process.env.TRUST_PROXY ?? '',
    limitarTentativas: sobrescritas.limitarTentativas ?? true,
  };
}

module.exports = { carregarConfig };
