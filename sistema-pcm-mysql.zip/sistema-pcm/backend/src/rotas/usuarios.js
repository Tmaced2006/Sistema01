'use strict';
const express = require('express');
const V = require('../validacao');
const A = require('../autenticacao');
const { um, todos } = require('../db');

/**
 * Gestão da equipe. Todas as rotas exigem login de PCM.
 *   GET   /api/usuarios            lista a equipe
 *   POST  /api/usuarios            cadastra uma pessoa
 *   PATCH /api/usuarios/:id        muda nome, função ou ativa/desativa
 *   POST  /api/usuarios/:id/pin    define um novo PIN (o antigo para de valer)
 */
module.exports = function rotasUsuarios(db, exigirLogin) {
  const r = express.Router();
  const ass = V.assincrono;
  r.use(exigirLogin, A.exigirPcm);

  const porId = (id) => um(db, 'SELECT * FROM usuarios WHERE id = ?', [id]);

  r.get('/', ass(async (_req, res) => {
    const lista = await todos(db, 'SELECT id, matricula, nome, funcao, ativo FROM usuarios ORDER BY nome');
    res.json({ usuarios: lista.map(A.usuarioPublico) });
  }));

  r.post('/', ass(async (req, res) => {
    const nome = V.texto(req.body.nome, { campo: 'o nome', obrigatorio: true, max: 60 });
    const mat = V.matricula(req.body.matricula);
    const funcao = V.opcao(req.body.funcao, V.FUNCOES, 'Função');
    const hash = A.gerarHash(V.pin(req.body.pin));
    if (await um(db, 'SELECT id FROM usuarios WHERE matricula = ?', [mat])) {
      throw new V.ErroHttp(409, 'Já existe um usuário com essa matrícula.');
    }
    let info;
    try {
      [info] = await db.execute(
        'INSERT INTO usuarios (matricula, nome, funcao, pin_hash, ativo, token_versao, criado_em) VALUES (?,?,?,?,1,0,?)',
        [mat, nome, funcao, hash, Date.now()]
      );
    } catch (e) {
      // Duas pessoas cadastrando a mesma matrícula no mesmo instante.
      if (e.code === 'ER_DUP_ENTRY') throw new V.ErroHttp(409, 'Já existe um usuário com essa matrícula.');
      throw e;
    }
    res.status(201).json({ usuario: A.usuarioPublico(await porId(info.insertId)) });
  }));

  r.patch('/:id', ass(async (req, res) => {
    const id = V.inteiro(req.params.id, 'Usuário');
    const u = await porId(id);
    if (!u) throw new V.ErroHttp(404, 'Usuário não encontrado.');
    const ehEu = id === req.usuario.id;

    const nome = req.body.nome !== undefined
      ? V.texto(req.body.nome, { campo: 'o nome', obrigatorio: true, max: 60 }) : u.nome;
    const funcao = req.body.funcao !== undefined ? V.opcao(req.body.funcao, V.FUNCOES, 'Função') : u.funcao;
    const ativo = req.body.ativo !== undefined ? (req.body.ativo ? 1 : 0) : u.ativo;

    if (ehEu && (funcao !== u.funcao || !ativo)) {
      throw new V.ErroHttp(400, 'Você não pode mudar a própria função nem desativar o próprio acesso.');
    }
    const deixaDeSerPcmAtivo = u.funcao === 'pcm' && u.ativo && (funcao !== 'pcm' || !ativo);
    if (deixaDeSerPcmAtivo) {
      const outros = await um(
        db, "SELECT COUNT(*) AS n FROM usuarios WHERE funcao = 'pcm' AND ativo = 1 AND id <> ?", [id]
      );
      if (Number(outros.n) === 0) throw new V.ErroHttp(400, 'É preciso manter pelo menos um PCM ativo.');
    }
    // Desativar ou mudar de função derruba os logins abertos da pessoa.
    const derrubar = (!ativo && u.ativo) || funcao !== u.funcao ? 1 : 0;
    await db.execute(
      'UPDATE usuarios SET nome = ?, funcao = ?, ativo = ?, token_versao = token_versao + ? WHERE id = ?',
      [nome, funcao, ativo, derrubar, id]
    );
    res.json({ usuario: A.usuarioPublico(await porId(id)) });
  }));

  r.post('/:id/pin', ass(async (req, res) => {
    const id = V.inteiro(req.params.id, 'Usuário');
    if (!(await porId(id))) throw new V.ErroHttp(404, 'Usuário não encontrado.');
    const hash = A.gerarHash(V.pin(req.body.pin));
    await db.execute('UPDATE usuarios SET pin_hash = ?, token_versao = token_versao + 1 WHERE id = ?', [hash, id]);
    res.json({ ok: true });
  }));

  return r;
};
