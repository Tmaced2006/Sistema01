'use strict';
const express = require('express');
const V = require('../validacao');
const A = require('../autenticacao');
const { um, todos, comTransacao } = require('../db');

/**
 * Atividades (ordens de serviço).
 *   GET    /api/os?semana=AAAA-MM-DD[&responsavel=ID]   atividades da semana
 *   GET    /api/os/atrasadas?antes=AAAA-MM-DD           pendentes de semanas anteriores
 *   POST   /api/os                                      cria (PCM)
 *   PATCH  /api/os/:id                                  edita (PCM)
 *   DELETE /api/os/:id                                  exclui (PCM)
 *   POST   /api/os/:id/status                           marca finalizada / não finalizada + observação
 *
 * Quem não é PCM só enxerga e só mexe nas atividades em que é o responsável.
 * Essa regra é aplicada aqui no servidor, não depende da tela.
 */
module.exports = function rotasAtividades(db, exigirLogin) {
  const r = express.Router();
  const ass = V.assincrono;
  r.use(exigirLogin);

  const BASE = `
    SELECT o.*, u.nome AS responsavel_nome, u.funcao AS responsavel_funcao
    FROM os o JOIN usuarios u ON u.id = o.responsavel_id`;
  const porId = (id) => um(db, `${BASE} WHERE o.id = ?`, [id]);

  async function historicoDe(ids) {
    if (!ids.length) return new Map();
    const marcas = ids.map(() => '?').join(',');
    const linhas = await todos(
      db,
      `SELECT os_id, em, por_nome, status, observacao FROM os_historico
       WHERE os_id IN (${marcas}) ORDER BY em ASC, id ASC`,
      ids
    );
    const mapa = new Map();
    for (const l of linhas) {
      if (!mapa.has(l.os_id)) mapa.set(l.os_id, []);
      mapa.get(l.os_id).push({ em: l.em, por: l.por_nome, status: l.status, observacao: l.observacao });
    }
    return mapa;
  }

  async function formatar(linhas) {
    const hist = await historicoDe(linhas.map((l) => l.id));
    return linhas.map((o) => ({
      id: o.id,
      numero: o.numero,
      titulo: o.titulo,
      equipamento: o.equipamento,
      tipo: o.tipo,
      prioridade: o.prioridade,
      data: o.data,
      semana: o.semana,
      descricao: o.descricao,
      status: o.status,
      observacao: o.observacao,
      atualizadoEm: o.atualizado_em,
      responsavelId: o.responsavel_id,
      responsavelNome: o.responsavel_nome,
      responsavelFuncao: o.responsavel_funcao,
      historico: (hist.get(o.id) || []).slice(-5),
    }));
  }

  function podeVer(req, o) {
    return req.usuario.funcao === 'pcm' || o.responsavel_id === req.usuario.id;
  }

  r.get('/', ass(async (req, res) => {
    const semana = V.segundaDaSemana(V.dataIso(req.query.semana, 'Semana'));
    const condicoes = ['o.semana = ?'];
    const params = [semana];
    if (req.usuario.funcao !== 'pcm') {
      condicoes.push('o.responsavel_id = ?'); params.push(req.usuario.id);
    } else if (req.query.responsavel) {
      condicoes.push('o.responsavel_id = ?'); params.push(V.inteiro(req.query.responsavel, 'Responsável'));
    }
    const linhas = await todos(db, `${BASE} WHERE ${condicoes.join(' AND ')} ORDER BY o.data, o.id`, params);
    res.json({ semana, atividades: await formatar(linhas) });
  }));

  r.get('/atrasadas', ass(async (req, res) => {
    const antes = V.dataIso(req.query.antes, 'Data');
    const condicoes = ["o.status IN ('pendente','nao_concluida')", 'o.data < ?'];
    const params = [antes];
    if (req.usuario.funcao !== 'pcm') {
      condicoes.push('o.responsavel_id = ?'); params.push(req.usuario.id);
    }
    const linhas = await todos(
      db, `${BASE} WHERE ${condicoes.join(' AND ')} ORDER BY o.data, o.id LIMIT 300`, params
    );
    res.json({ atividades: await formatar(linhas) });
  }));

  /** Valida os campos de uma atividade (usado para criar e editar). */
  async function ler(corpo) {
    const data = V.dataIso(corpo.data);
    const resp = await um(
      db, 'SELECT id, funcao, ativo FROM usuarios WHERE id = ?', [V.inteiro(corpo.responsavelId, 'Responsável')]
    );
    if (!resp || !resp.ativo || resp.funcao === 'pcm') {
      throw new V.ErroHttp(400, 'Escolha um mecânico, eletricista ou pessoal de predial ativo como responsável.');
    }
    return {
      numero: V.texto(corpo.numero, { campo: 'o número da OS', max: 30 }),
      titulo: V.texto(corpo.titulo, { campo: 'o título da atividade', obrigatorio: true, max: 120 }),
      equipamento: V.texto(corpo.equipamento, { campo: 'o equipamento', obrigatorio: true, max: 80 }),
      tipo: V.opcao(corpo.tipo || 'preventiva', V.TIPOS, 'Tipo'),
      prioridade: V.opcao(corpo.prioridade || 'normal', V.PRIORIDADES, 'Prioridade'),
      data,
      semana: V.segundaDaSemana(data),
      responsavel_id: resp.id,
      descricao: V.texto(corpo.descricao, { campo: 'a descrição', max: 1500 }),
    };
  }

  r.post('/', A.exigirPcm, ass(async (req, res) => {
    const c = await ler(req.body);
    const [info] = await db.execute(
      `INSERT INTO os (numero, titulo, equipamento, tipo, prioridade, \`data\`, semana, responsavel_id, descricao,
                       status, observacao, criado_por, criado_em)
       VALUES (?,?,?,?,?,?,?,?,?,'pendente','',?,?)`,
      [c.numero, c.titulo, c.equipamento, c.tipo, c.prioridade, c.data, c.semana, c.responsavel_id, c.descricao,
        req.usuario.id, Date.now()]
    );
    res.status(201).json({ atividade: (await formatar([await porId(info.insertId)]))[0] });
  }));

  r.patch('/:id', A.exigirPcm, ass(async (req, res) => {
    const id = V.inteiro(req.params.id, 'Atividade');
    if (!(await porId(id))) throw new V.ErroHttp(404, 'Atividade não encontrada.');
    const c = await ler(req.body);
    await db.execute(
      `UPDATE os SET numero=?, titulo=?, equipamento=?, tipo=?, prioridade=?,
                     \`data\`=?, semana=?, responsavel_id=?, descricao=?
       WHERE id=?`,
      [c.numero, c.titulo, c.equipamento, c.tipo, c.prioridade, c.data, c.semana, c.responsavel_id, c.descricao, id]
    );
    res.json({ atividade: (await formatar([await porId(id)]))[0] });
  }));

  r.delete('/:id', A.exigirPcm, ass(async (req, res) => {
    const id = V.inteiro(req.params.id, 'Atividade');
    const [info] = await db.execute('DELETE FROM os WHERE id = ?', [id]);
    if (!info.affectedRows) throw new V.ErroHttp(404, 'Atividade não encontrada.');
    res.json({ ok: true });
  }));

  r.post('/:id/status', ass(async (req, res) => {
    const id = V.inteiro(req.params.id, 'Atividade');
    const o = await porId(id);
    // Para quem não é o responsável a atividade "não existe": não revela que há outras.
    if (!o || !podeVer(req, o)) throw new V.ErroHttp(404, 'Atividade não encontrada.');
    const status = V.opcao(req.body.status, ['concluida', 'nao_concluida'], 'Situação');
    const observacao = V.texto(req.body.observacao, { campo: 'a observação', max: 1000 });
    const agora = Date.now();
    await comTransacao(db, async (cx) => {
      await cx.execute(
        'UPDATE os SET status = ?, observacao = ?, atualizado_por = ?, atualizado_em = ? WHERE id = ?',
        [status, observacao, req.usuario.id, agora, id]
      );
      await cx.execute(
        'INSERT INTO os_historico (os_id, em, por_id, por_nome, status, observacao) VALUES (?,?,?,?,?,?)',
        [id, agora, req.usuario.id, req.usuario.nome, status, observacao]
      );
    });
    res.json({ atividade: (await formatar([await porId(id)]))[0] });
  }));

  return r;
};
