'use strict';
if (parseInt(process.versions.node.split('.')[0], 10) < 18) {
  console.error('Este sistema precisa do Node.js 18 ou mais novo. Versão instalada: ' + process.versions.node);
  console.error('Baixe a versão LTS em https://nodejs.org e tente de novo.');
  process.exit(1);
}
const { carregarConfig } = require('./config');
const { criarApp } = require('./app');

/** Traduz os erros mais comuns de conexão com o MySQL para uma orientação em português. */
function explicarErroBanco(e, db) {
  console.error('');
  console.error('NÃO FOI POSSÍVEL CONECTAR AO BANCO DE DADOS (MySQL).');
  if (e.code === 'ECONNREFUSED' || e.code === 'ETIMEDOUT' || e.code === 'ENOTFOUND') {
    console.error(`O MySQL não respondeu em ${db.host}:${db.port}.`);
    console.error('Confira se o MySQL está instalado e ligado, e se DB_HOST e DB_PORT estão certos em configuracao.env.');
  } else if (e.code === 'ER_ACCESS_DENIED_ERROR') {
    console.error(`O MySQL recusou o usuário "${db.user}" ou a senha.`);
    console.error('Confira DB_USER e DB_PASSWORD em configuracao.env.');
  } else if (e.code === 'ER_BAD_DB_ERROR') {
    console.error(`O banco "${db.database}" não existe.`);
    console.error('Rode o script banco/criar-banco.sql (veja o LEIA-ME) e tente de novo.');
  } else {
    console.error(e.message);
    if (e.code) console.error('Código do erro: ' + e.code);
  }
  console.error('');
}

async function main() {
  const config = carregarConfig();
  let app;
  try {
    app = await criarApp(config);
  } catch (e) {
    explicarErroBanco(e, config.db);
    process.exit(1);
  }

  const servidor = app.listen(config.porta, '0.0.0.0', () => {
    console.log('Programação de Manutenção no ar.');
    console.log(`  Neste computador:  http://localhost:${config.porta}`);
    console.log(`  Banco de dados:    MySQL ${config.db.database} em ${config.db.host}:${config.db.port}`);
  });

  function encerrar() {
    servidor.close(async () => {
      try { await app.locals.db.end(); } catch (e) { /* já fechado */ }
      process.exit(0);
    });
  }
  process.on('SIGINT', encerrar);
  process.on('SIGTERM', encerrar);
}

main().catch((e) => { console.error(e); process.exit(1); });
