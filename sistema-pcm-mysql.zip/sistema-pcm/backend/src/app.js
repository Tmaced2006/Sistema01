'use strict';
const express = require('express');
const helmet = require('helmet');
const { abrirBanco } = require('./db');
const { exigirLogin } = require('./autenticacao');
const { ErroHttp } = require('./validacao');
const rotasAcesso = require('./rotas/acesso');
const rotasUsuarios = require('./rotas/usuarios');
const rotasAtividades = require('./rotas/atividades');

/** Monta o servidor (API + telas). Separado do server.js para os testes poderem usar. */
async function criarApp(config) {
  const db = await abrirBanco(config.db);
  const app = express();

  if (config.trustProxy !== '') {
    const n = Number(config.trustProxy);
    app.set('trust proxy', Number.isNaN(n) ? config.trustProxy : n);
  }

  app.use(helmet({
    contentSecurityPolicy: {
      useDefaults: false,
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'"],
        styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
        fontSrc: ['https://fonts.gstatic.com'],
        imgSrc: ["'self'", 'data:'],
        connectSrc: ["'self'"],
        objectSrc: ["'none'"],
        baseUri: ["'self'"],
        frameAncestors: ["'none'"],
      },
    },
    hsts: false, // o HTTPS é cuidado por quem hospeda (Render, Nginx...)
  }));
  app.use(express.json({ limit: '50kb' }));

  const login = exigirLogin(db, config);
  const api = express.Router();
  api.use(rotasAcesso(db, config, login));
  api.use('/usuarios', rotasUsuarios(db, login));
  api.use('/os', rotasAtividades(db, login));
  api.use((_req, _res, next) => next(new ErroHttp(404, 'Rota não encontrada.')));
  app.use('/api', api);
  app.use('/api', (_req, res) => res.status(404).json({ erro: 'Rota não encontrada.' }));

  app.use(express.static(config.pastaFrontend, { maxAge: '5m' }));

  // eslint-disable-next-line no-unused-vars
  app.use((err, _req, res, _next) => {
    if (err instanceof ErroHttp) return res.status(err.status).json({ erro: err.message });
    if (err && err.type === 'entity.parse.failed') return res.status(400).json({ erro: 'Dados inválidos.' });
    if (err && err.type === 'entity.too.large') return res.status(413).json({ erro: 'Dados grandes demais.' });
    console.error(err);
    res.status(500).json({ erro: 'Erro interno. Tente de novo em instantes.' });
  });

  app.locals.db = db;
  return app;
}

module.exports = { criarApp };
