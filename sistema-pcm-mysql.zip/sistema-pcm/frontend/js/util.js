/* Utilidades: criar elementos, datas, textos fixos, avisos e janela de detalhes. */
(function () {
  'use strict';
  var U = {};

  U.DIAS = ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'];
  U.TIPOS = [['preventiva', 'Preventiva'], ['corretiva', 'Corretiva'], ['preditiva', 'Preditiva'], ['inspecao', 'Inspeção'], ['melhoria', 'Melhoria']];
  U.PRIO = [['normal', 'Normal'], ['alta', 'Alta'], ['urgente', 'Urgente']];
  U.FUNCOES = [['mecanico', 'Mecânico'], ['eletricista', 'Eletricista'], ['predial', 'Predial']];
  U.STATUS_LABEL = { pendente: 'Pendente', concluida: 'Finalizada', nao_concluida: 'Não finalizada' };
  U.FILTROS = [['todas', 'Todas'], ['pendente', 'Pendentes'], ['concluida', 'Finalizadas'], ['nao_concluida', 'Não finalizadas'], ['obs', 'Com observação']];

  U.ICON = {
    pendente: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/></svg>',
    concluida: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9" fill="currentColor"/><path d="M7.5 12.5l3 3 6-6.5" stroke="#fff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    nao_concluida: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M12 3a9 9 0 0 1 0 18z" fill="currentColor" stroke="none"/></svg>',
    note: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M5 4h14v12l-5 4H5z"/><path d="M8 9h8M8 13h5" stroke-linecap="round"/></svg>',
    left: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 5l-7 7 7 7"/></svg>',
    right: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 5l7 7-7 7"/></svg>',
    x: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>'
  };

  /** Cria um elemento: h('div', {class:'x', onclick:fn}, filhos...). Texto sempre entra como texto. */
  U.h = function (tag, props) {
    var e = document.createElement(tag), k, v, kids = Array.prototype.slice.call(arguments, 2);
    props = props || {};
    for (k in props) {
      v = props[k];
      if (v == null || v === false) continue;
      if (k === 'class') e.className = v;
      else if (k === 'html') e.innerHTML = v; // só para os ícones fixos deste arquivo
      else if (k.slice(0, 2) === 'on') e.addEventListener(k.slice(2), v);
      else if (k === 'value') e.value = v;
      else if (v === true) e.setAttribute(k, '');
      else e.setAttribute(k, v);
    }
    (function add(list) {
      list.forEach(function (c) {
        if (c == null || c === false) return;
        if (Array.isArray(c)) return add(c);
        e.append(c.nodeType ? c : document.createTextNode(String(c)));
      });
    })(kids);
    return e;
  };

  /* ---------- datas ---------- */
  U.pad = function (n) { return n < 10 ? '0' + n : '' + n; };
  U.ymd = function (d) { return d.getFullYear() + '-' + U.pad(d.getMonth() + 1) + '-' + U.pad(d.getDate()); };
  U.parseYmd = function (s) { var p = s.split('-').map(Number); return new Date(p[0], p[1] - 1, p[2]); };
  U.addDays = function (d, n) { var x = new Date(d.getFullYear(), d.getMonth(), d.getDate()); x.setDate(x.getDate() + n); return x; };
  U.weekStart = function (date) {
    var d = new Date(date.getFullYear(), date.getMonth(), date.getDate());
    d.setDate(d.getDate() - ((d.getDay() + 6) % 7));
    return d;
  };
  U.isoWeek = function (d) {
    var t = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
    var dn = t.getUTCDay() || 7;
    t.setUTCDate(t.getUTCDate() + 4 - dn);
    var y0 = new Date(Date.UTC(t.getUTCFullYear(), 0, 1));
    return Math.ceil(((t - y0) / 86400000 + 1) / 7);
  };
  U.shortDate = function (d) { return d.toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' }).replace('.', ''); };
  U.dayLabel = function (s) { var d = U.parseYmd(s); return U.DIAS[d.getDay()] + ' · ' + U.pad(d.getDate()) + '/' + U.pad(d.getMonth() + 1); };
  U.stamp = function (ts) { return new Date(ts).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }); };

  U.funcLabel = function (f) {
    if (f === 'pcm') return 'PCM';
    var x = U.FUNCOES.filter(function (o) { return o[0] === f; })[0];
    return x ? x[1] : 'Mecânico';
  };
  U.tipoLabel = function (t) { var x = U.TIPOS.filter(function (o) { return o[0] === t; })[0]; return x ? x[1] : ''; };
  U.prioLabel = function (p) { var x = U.PRIO.filter(function (o) { return o[0] === p; })[0]; return x ? x[1] : 'Normal'; };

  /* ---------- campos de formulário ---------- */
  U.inp = function (id, props) { return U.h('input', Object.assign({ id: id, class: 'in' }, props || {})); };
  U.sel = function (id, opts, val) {
    var s = U.h('select', { id: id, class: 'in' }, opts.map(function (o) { return U.h('option', { value: o[0] }, o[1]); }));
    s.value = val;
    return s;
  };
  U.field = function (label, input, hint) {
    return U.h('div', { class: 'field' }, U.h('label', { for: input.id }, label), input, hint ? U.h('p', { class: 'hint' }, hint) : null);
  };

  /* ---------- aviso rápido e janela de detalhes ---------- */
  var toastTimer;
  U.toast = function (msg, bad) {
    var el = document.getElementById('toast');
    el.textContent = msg;
    el.className = 'toast' + (bad ? ' bad' : '');
    el.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { el.hidden = true; }, bad ? 6000 : 2600);
  };

  U.closeSheet = function () {
    var el = document.getElementById('sheet');
    el.hidden = true;
    el.replaceChildren();
  };
  U.openSheet = function (title, body) {
    var el = document.getElementById('sheet');
    el.replaceChildren(
      U.h('div', { class: 'overlay', onmousedown: function (e) { if (e.target === e.currentTarget) U.closeSheet(); } },
        U.h('div', { class: 'sheet', role: 'dialog', 'aria-modal': 'true', 'aria-label': title },
          U.h('div', { class: 'sheet-head' },
            U.h('h2', {}, title),
            U.h('button', { type: 'button', class: 'icon-btn', 'aria-label': 'Fechar', onclick: U.closeSheet, html: U.ICON.x })),
          body)));
    el.hidden = false;
  };
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && !document.getElementById('sheet').hidden) U.closeSheet();
  });

  window.PCM = window.PCM || {};
  window.PCM.util = U;
})();
