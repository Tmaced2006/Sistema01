-- ============================================================================
--  Cria o banco, o usuário do sistema e as tabelas.
--  Rode UMA vez, com o usuário administrador (root) do MySQL.
--
--  ANTES DE RODAR: troque 'troque-esta-senha' (aparece 2 vezes abaixo) por uma
--  senha sua e use a MESMA senha em DB_PASSWORD no arquivo configuracao.env.
-- ============================================================================

CREATE DATABASE IF NOT EXISTS pcm        CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
-- Banco usado só pelos testes automáticos (npm test). Pode apagar esta linha se não for rodar testes.
CREATE DATABASE IF NOT EXISTS pcm_teste  CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;

CREATE USER IF NOT EXISTS 'pcm_app'@'localhost' IDENTIFIED BY 'troque-esta-senha';
GRANT ALL PRIVILEGES ON pcm.*       TO 'pcm_app'@'localhost';
GRANT ALL PRIVILEGES ON pcm_teste.* TO 'pcm_app'@'localhost';
FLUSH PRIVILEGES;

-- Se o sistema e o MySQL ficarem em computadores diferentes, crie também o usuário para o endereço
-- do computador do sistema (exemplo para o IP 192.168.0.25), com a mesma senha:
--   CREATE USER IF NOT EXISTS 'pcm_app'@'192.168.0.25' IDENTIFIED BY 'troque-esta-senha';
--   GRANT ALL PRIVILEGES ON pcm.* TO 'pcm_app'@'192.168.0.25';

USE pcm;

CREATE TABLE IF NOT EXISTS usuarios (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  matricula     VARCHAR(50)  NOT NULL UNIQUE,
  nome          VARCHAR(60)  NOT NULL,
  funcao        ENUM('pcm','mecanico','eletricista','predial') NOT NULL,
  pin_hash      VARCHAR(100) NOT NULL,
  ativo         TINYINT(1)   NOT NULL DEFAULT 1,
  token_versao  INT          NOT NULL DEFAULT 0,
  criado_em     BIGINT       NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS os (
  id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  numero          VARCHAR(30)   NOT NULL DEFAULT '',
  titulo          VARCHAR(120)  NOT NULL,
  equipamento     VARCHAR(80)   NOT NULL,
  tipo            ENUM('preventiva','corretiva','preditiva','inspecao','melhoria') NOT NULL DEFAULT 'preventiva',
  prioridade      ENUM('normal','alta','urgente') NOT NULL DEFAULT 'normal',
  `data`          CHAR(10)      NOT NULL,
  semana          CHAR(10)      NOT NULL,
  responsavel_id  INT UNSIGNED  NOT NULL,
  descricao       VARCHAR(1500) NOT NULL DEFAULT '',
  status          ENUM('pendente','concluida','nao_concluida') NOT NULL DEFAULT 'pendente',
  observacao      VARCHAR(1000) NOT NULL DEFAULT '',
  atualizado_por  INT UNSIGNED  NULL,
  atualizado_em   BIGINT        NULL,
  criado_por      INT UNSIGNED  NOT NULL,
  criado_em       BIGINT        NOT NULL,
  FOREIGN KEY (responsavel_id) REFERENCES usuarios(id),
  FOREIGN KEY (atualizado_por) REFERENCES usuarios(id),
  FOREIGN KEY (criado_por)     REFERENCES usuarios(id),
  INDEX idx_os_semana (semana),
  INDEX idx_os_resp_status (responsavel_id, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS os_historico (
  id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  os_id      INT UNSIGNED  NOT NULL,
  em         BIGINT        NOT NULL,
  por_id     INT UNSIGNED  NOT NULL,
  por_nome   VARCHAR(60)   NOT NULL,
  status     VARCHAR(20)   NOT NULL,
  observacao VARCHAR(1000) NOT NULL DEFAULT '',
  FOREIGN KEY (os_id)  REFERENCES os(id) ON DELETE CASCADE,
  FOREIGN KEY (por_id) REFERENCES usuarios(id),
  INDEX idx_hist_os (os_id, em)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
